# Melodarium - build_windows.ps1 (builds the Windows app)
# Copyright (C) 2026 Joshua Nichols
# https://github.com/joshdnichols/Melodarium
#
# This program is free software: you can redistribute it and/or modify it under the
# terms of the GNU General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your option) any later version.
# This program is distributed WITHOUT ANY WARRANTY; see the file LICENSE for details.
# ---------------------------------------------------------------------------
#  Builds the Windows app "Melodarium" (a folder with Melodarium.exe,
#  LilyPond and the music fonts inside), then zips it for sharing.
#
#  Run it by double-clicking BUILD-WINDOWS.bat (which starts this script), or from
#  PowerShell inside this folder:   powershell -ExecutionPolicy Bypass -File build_windows.ps1
#
#  Needs: Python 3.11-3.14 from python.org (with "py" launcher), internet access for
#  the Python packages and (unless already in this folder) the LilyPond download.
# ---------------------------------------------------------------------------
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"   # much faster downloads and unzipping
Set-Location -LiteralPath $PSScriptRoot

$AppName     = "Melodarium"
$LyVersion   = "2.26.0"
$LyShort     = "2.26"
$LyZip       = "lilypond-$LyVersion-mingw-x86_64.zip"
$LyUrl       = "https://gitlab.com/lilypond/lilypond/-/releases/v$LyVersion/downloads/$LyZip"
$LySrc       = "lilypond-$LyVersion.tar.gz"
$LySrcUrl    = "https://lilypond.org/download/source/v$LyShort/$LySrc"
$Kit         = $PSScriptRoot
$Build       = Join-Path $Kit "build"
$Dist        = Join-Path $Kit "dist"
$Downloads   = Join-Path $Kit "downloads"
$Venv        = Join-Path $Build "venv"
$AppDir      = Join-Path $Dist $AppName

function Step($text) { Write-Host ""; Write-Host "==> $text" -ForegroundColor Cyan }
function Fail($text) { Write-Host ""; Write-Host "BUILD STOPPED: $text" -ForegroundColor Red; exit 1 }

# --- 0. kit complete? -------------------------------------------------------
foreach ($need in @("melodarium.py", "selftest.py", "collect_licenses.py", "LICENSE", "NOTICE.txt", "icon.ico", "licenses", "fonts\otf", "fonts\svg")) {
    if (-not (Test-Path (Join-Path $Kit $need))) { Fail "'$need' is missing from this folder. Unzip the whole build kit first." }
}

# --- 1. Python ---------------------------------------------------------------
Step "Checking Python"
$py = $null
foreach ($v in @("-3.13", "-3.12", "-3.14", "-3.11")) {
    try { & py $v -c "import sys" 2>$null; if ($LASTEXITCODE -eq 0) { $py = @("py", $v); break } } catch {}
}
if (-not $py) { Fail "Python 3.11-3.14 from python.org wasn't found (the 'py' launcher). See step 1 of the instructions." }
& $py[0] $py[1] -c "import tkinter"
if ($LASTEXITCODE -ne 0) { Fail "This Python has no tkinter (needed for the Browse button). Reinstall Python from python.org with 'tcl/tk and IDLE' ticked." }
& $py[0] $py[1] --version

# --- 2. build tools in a private virtual environment -------------------------
Step "Installing PyInstaller and Pillow (for building) and pywebview (the app window)"
New-Item -ItemType Directory -Force -Path $Build, $Downloads | Out-Null
if (-not (Test-Path (Join-Path $Venv "Scripts\python.exe"))) { & $py[0] $py[1] -m venv $Venv }
$VPy = Join-Path $Venv "Scripts\python.exe"
& $VPy -m pip install --upgrade pip | Out-Null
& $VPy -m pip install --upgrade "pyinstaller>=6.10,<7" "pillow>=10" "pywebview>=5,<7"
if ($LASTEXITCODE -ne 0) { Fail "Couldn't install PyInstaller/Pillow/pywebview (check the internet connection)." }
& $VPy -c "import webview"
if ($LASTEXITCODE -ne 0) { Fail "pywebview was installed but doesn't load (see the error above)." }
Write-Host "Collecting the licenses of the Python packages that go inside the app:"
$PyLicenses = Join-Path $Build "licenses-python"
& $VPy (Join-Path $Kit "collect_licenses.py") $PyLicenses pywebview
if ($LASTEXITCODE -ne 0) { Fail "Couldn't collect the package licenses (see above)." }

# --- 3. LilyPond -------------------------------------------------------------
Step "Getting LilyPond $LyVersion for Windows"
$zipPath = Join-Path $Kit $LyZip
if (-not (Test-Path $zipPath)) { $zipPath = Join-Path $Downloads $LyZip }
if (-not (Test-Path $zipPath)) {
    Write-Host "Downloading $LyUrl"
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri $LyUrl -OutFile $zipPath -UseBasicParsing
}
$lyStage = Join-Path $Build "lilypond"
if (Test-Path $lyStage) { Remove-Item -Recurse -Force $lyStage }
Expand-Archive -Path $zipPath -DestinationPath $lyStage
$lyRoot = Join-Path $lyStage "lilypond-$LyVersion"
if (-not (Test-Path (Join-Path $lyRoot "bin\lilypond.exe"))) { Fail "The LilyPond zip doesn't contain lilypond-$LyVersion\bin\lilypond.exe." }

# --- 4. music fonts into LilyPond's own font folders -------------------------
Step "Installing the music fonts into LilyPond"
$fontDir = Join-Path $lyRoot "share\lilypond\$LyVersion\fonts"
Copy-Item -Path (Join-Path $Kit "fonts\otf\*") -Destination (Join-Path $fontDir "otf") -Force
Copy-Item -Path (Join-Path $Kit "fonts\svg\*") -Destination (Join-Path $fontDir "svg") -Force
Write-Host ("{0} font files installed." -f ((Get-ChildItem (Join-Path $Kit "fonts\otf")).Count + (Get-ChildItem (Join-Path $Kit "fonts\svg")).Count))

# --- 5. check LilyPond + fonts + outline before packaging --------------------
Step "Self-test: engraving test scores with the bundled LilyPond"
& $VPy (Join-Path $Kit "selftest.py") (Join-Path $lyRoot "bin\lilypond.exe")
if ($LASTEXITCODE -ne 0) { Fail "The self-test failed (see the FAIL lines above)." }

# --- 6. the app itself -------------------------------------------------------
Step "Building $AppName.exe with PyInstaller"
if (Test-Path $AppDir) { Remove-Item -Recurse -Force $AppDir }
& $VPy -m PyInstaller --noconfirm --clean `
    --onedir --windowed `
    --name $AppName `
    --icon (Join-Path $Kit "icon.ico") `
    --add-data ("{0};licenses" -f (Join-Path $Kit "licenses")) `
    --add-data ("{0};licenses\python" -f $PyLicenses) `
    --hidden-import tkinter --hidden-import tkinter.filedialog `
    --collect-all webview --collect-all clr_loader --collect-all pythonnet --hidden-import clr `
    --distpath $Dist --workpath (Join-Path $Build "pyinstaller") --specpath $Build `
    (Join-Path $Kit "melodarium.py")
if ($LASTEXITCODE -ne 0) { Fail "PyInstaller reported an error (see above)." }

# --- 7. LilyPond goes next to the .exe ---------------------------------------
Step "Adding LilyPond to the app folder"
$lyTarget = Join-Path $AppDir "lilypond"
New-Item -ItemType Directory -Force -Path $lyTarget | Out-Null
Move-Item -Path $lyRoot -Destination $lyTarget
Step "Self-test again, from inside the finished app folder"
& $VPy (Join-Path $Kit "selftest.py") (Join-Path $lyTarget "lilypond-$LyVersion\bin\lilypond.exe")
if ($LASTEXITCODE -ne 0) { Fail "The self-test failed inside the app folder." }

# --- 8. license / source notes -----------------------------------------------
Step "Adding license notes"
Copy-Item (Join-Path $Kit "LICENSE") (Join-Path $AppDir "LICENSE.txt")
Copy-Item (Join-Path $Kit "NOTICE.txt") (Join-Path $AppDir "NOTICE.txt")
@"
Melodarium
==========
Start the program with "Melodarium.exe". It opens in its own window. (If Windows is
missing Microsoft's WebView2 Runtime, it opens in your web browser instead and tells you
where to get WebView2; it's free and already part of Windows 11.)
Your settings, progress and (by default) your scores are kept in this folder. If this folder
can't be written to (for example inside Program Files), they go to Documents\Melodarium.

Copyright (C) 2026 Joshua Nichols. Melodarium is free software: you can share and change
it under the GNU General Public License, version 3 or (at your option) any later version
(LICENSE.txt). It comes with NO WARRANTY, to the extent permitted by law. The code it
writes into your scores may be used under CC0 1.0 (public domain); see NOTICE.txt.
Source code: Melodarium-source.zip in the "source" folder of the download,
and https://github.com/joshdnichols/Melodarium

Included software and fonts are listed, with their licenses, on the Acknowledgements page
(link at the top of the control panel). License files are in:
  _internal\licenses\              music fonts, Emmentaler
  lilypond\lilypond-$LyVersion\licenses\   LilyPond and the programs it includes

LilyPond is free software under the GNU General Public License v3. Its source code:
  $LySrcUrl
  (a copy of $LySrc is shipped alongside this app, in the "source" folder of the download)
"@ | Set-Content -Encoding UTF8 (Join-Path $AppDir "READ ME.txt")

# --- 9. source + zip for sharing ---------------------------------------------
Step "Fetching LilyPond's source code (shipped alongside the app for the GPL)"
$srcPath = Join-Path $Downloads $LySrc
if (-not (Test-Path $srcPath)) {
    try { Invoke-WebRequest -Uri $LySrcUrl -OutFile $srcPath -UseBasicParsing }
    catch { Write-Host "Couldn't download $LySrcUrl - download it yourself into the 'downloads' folder before sharing." -ForegroundColor Yellow }
}
$share = Join-Path $Dist "share"
if (Test-Path $share) { Remove-Item -Recurse -Force $share }
New-Item -ItemType Directory -Force -Path (Join-Path $share "source") | Out-Null
Copy-Item -Recurse $AppDir (Join-Path $share $AppName)
if (Test-Path $srcPath) { Copy-Item $srcPath (Join-Path $share "source") }
# Melodarium's own source: this kit, without the build output and downloads (for the GPL)
$srcStage = Join-Path $Build "source\Melodarium-source"
if (Test-Path (Join-Path $Build "source")) { Remove-Item -Recurse -Force (Join-Path $Build "source") }
New-Item -ItemType Directory -Force -Path $srcStage | Out-Null
Get-ChildItem -LiteralPath $Kit -Force | Where-Object {
    $_.Name -notin @("build", "dist", "downloads", "__pycache__") -and $_.Name -notlike "*.tar.gz" -and $_.Name -notlike "lilypond-*.zip"
} | ForEach-Object { Copy-Item -Recurse -LiteralPath $_.FullName -Destination $srcStage }
Get-ChildItem -Recurse -Directory -Path $srcStage -Filter "__pycache__" | Remove-Item -Recurse -Force
Compress-Archive -Path $srcStage -DestinationPath (Join-Path $share "source\Melodarium-source.zip") -CompressionLevel Optimal
$zipOut = Join-Path $Dist "Melodarium-Windows.zip"
if (Test-Path $zipOut) { Remove-Item -Force $zipOut }
Step "Zipping (this takes a minute)"
Compress-Archive -Path (Join-Path $share "*") -DestinationPath $zipOut -CompressionLevel Optimal

Write-Host ""
Write-Host "DONE." -ForegroundColor Green
Write-Host "  App folder:      $AppDir"
Write-Host "  Start it with:   $AppDir\$AppName.exe"
Write-Host "  To share:        $zipOut"
