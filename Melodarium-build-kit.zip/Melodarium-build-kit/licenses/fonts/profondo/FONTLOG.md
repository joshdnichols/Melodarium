FONTLOG for the Profondo font
=============================

This file provides detailed information on the Profondo Font Software. This information should
be distributed along with the Profondo fonts and any derivative works. It is an un-modified
glyph re-mapping of Steinberg's Bravura font (also distributed under the OFL) to be compatible
with the LilyPond music engraving software.


Basic font information
----------------------

Bravura is a Unicode typeface designed by Steinberg for its in-development music notation and
scoring application.

It is compliant with version 0.9 of the Standard Music Font Layout (SMuFL), a community-driven
standard for how music symbols should be laid out in the Unicode Private Use Area (PUA) in the
Basic Multilingual Plane (BMP) for compatibility between different scoring applications.

More information about Steinberg's scoring application can be found at:

http://www.steinberg.net/

More information about SMuFL can be found at:

http://www.smufl.org/


Note for developers
-------------------

If you are intending to use Bravura as part of your own software application, please refer to
the 'Notes for implementers' section in the SMuFL specification for useful information about
Bravura's metrics and how glyphs are registered.


Changelog
---------

22 May 2013 (Daniel Spreadbury) Bravura version 0.1
- Initial pre-release to coincide with 2013 Music Encoding Conference

5 July 2013 (Daniel Spreadbury) Bravura version 0.2
- Bravura 0.2 is designed to be compatible with SMuFL 0.5
- Thanks to Mark Johnson and Emil Wojtacki for contributing a number of glyphs to the font
- Many existing code points have been changed, as a result of hundreds of new glyphs being added, plus a number of new ranges.
- Added long (U+E008) and very long (U+E009) system dividers for very large scores.
- Added heavy (U+E034), double heavy (U+E035) and dotted (U+E037) barlines.
- Added square coda (U+E047) and small repeat signs for repeats within bars (U+E04A, U+E04B).
- Added recommended stylistic alternates for segno (U+E045) and coda (U+E046) for the appearance preferred by Japanese publishers.
- Added quindicesima bassa G clef (U+E061) and F clef (U+E070), G clef combined with C clef (U+E066), G clefs designed to be ligated with numbers below and above to show the transposition of an instrument (U+E067, U+E068), plus recommended ligatures for G and F clefs with numbers above and below; also added G, C and F clefs with arrows up and down, which may be used either as alternatives for octave clefs or to represent the extremes of register on an instrument (U+E069, U+E06A, U+E06C, U+E06D, U+E074, U+E075), and semi-pitched percussion clefs (U+E078, U+E079), plus a bridge clef (U+E085).
- Removed “tall” versions of 6- and 4-string tab clefs, and instead made them recommended stylistic alternates, together with versions that use letterforms with serifs.
- Added +, -, X (multiply), comma, parentheses glyphs for time signatures (U+E09C–U+E0A6), plus basic fractions (U+E0A7–U+E0AB), and Penderecki-style open time signature (U+E0AD).
- Added specific noteheads for double whole note (U+E100) and whole note (U+E101) to the noteheads range rather than relying on the glyphs in the pre-composed notes range.
- Added shaped noteheads for specific note values (double whole note, whole note, half note, and quarter note and shorter); also added large up- and down-pointing triangles for highest/lowest notes played by an instrument (U+E102–U+E109).
- Added large slashed circular noteheads (U+E136–U+E139) as used by Stockhausen for notating gong/tam-tam hits.
- Added combining glyphs for note clusters of specific note values (U+E154–U+E171).
- Added noteheads with solfège and chromatic note names embedded within them, as seen in “EZ-Play” educational scores (U+E180–U+E1D9).
- Added specific range of noteheads for sacred harp shape note singing (U+E1E0–U+E1EF).
- Added pre-composed 1024th notes (U+E214–U+E215), tails (U+E28E–U+E28F) and rest (U+E52C).
- Added range for typing simple beamed groups of notes in text-based applications, (U+E220–U+E233). Designed to be used in conjunction with pre-composed notes (U+E200–U+E216), and allowing beamed groups with rhythmic values between 8th notes and 64th notes, plus ties and triplets.
- Added combining stems for multiphonics, damp, sussurando, Saunders vibrato pulse accent (U+E248–U+E24D).
- Added four- and five-stroke tremolos (U+E263–U+E264, U+E268–U+E269) plus Wieniawski-style unmeasured tremolo glyphs (U+E26C–U+26D).
- Added stylistic alternates for flags (U+E280–U+E28F): straight flags; and shorter stem-up flags to avoid collisions with augmentation dots.
- Separated accidentals into several discrete ranges based around the various accidental systems, including 12-edo, 24-edo, the system of up- and down-pointing arrows favoured by Gould, Stein-Zimmermann (also known as Tartini-Couper), Maneri-Sims, Ben Johnston, Marc Sabat and Wolfgang von Schweinitz’s Extended Helmholtz-Ellis Just Intonation Pitch Notation. A range has also been reserved for George Secor and Dave Keenan’s Sagittal system of accidentals (U+E360–U+E47F).
- Added accidentals used in Turkish folk music (U+E4C8–U+E4CF).
- Added Persian accidentals (U+E4D0–U+E4D1).
- Added staccatissimo wedge (U+E4E5–U+E4E6) and stroke (U+E4E7–U+E4E8) glyphs.
- Added very short (U+E502–U+E503) and very long (U+E508–U+E509) fermatas, plus short caesura (U+E50D).
- Added left and right halves of multirest H-bars (U+E52E–U+E52F) and old-style quarter rest as seen in e.g. Novello editions (U+E530).
- Added ventiduesima (three octaves, “22”) glyphs to octaves range (U+E557–U+E559).
- Added precomposed glyphs for common dynamics (U+E567–U+E57B) and niente circle for hairpins (U+E57E).
- Added schleifer (long mordent, U+E5AA) and Haydn ornament (U+E5D1).
- Added additional brass techniques, including short, medium and long versions of lift, doit, lip fall, smooth fall, rough fall, plus jazz turn (U+E5E0–U+E5FB).
- Added range of glyphs for embouchure tightness (U+E61B–U+E623), reed position (U+E624–U+E626), multiphonics (U+E627–U+E629), and stylistic alternates for double- and triple-tonguing with no slurs.
- Added further overpressure glyphs (U+E64B–U+E64D), plus jété, fouetté, Rebecca Saunders’s “vibrato pulse” accent and thumb position (U+E64E–U+E652) to string techniques range.
- Added plectrum pictogram (U+E669) and combining damp glyph for note stems (U+E66A) to plucked techniques range.
- Added arrows for breathing and intonation, plus combining sussurando glyph for note stems (U+E687–U+E68B), to vocal techniques range.
- Added pedal pictograms, sostenuto pedal symbols, and half-pedal marks (U+E6A5–U+E6AC) to keyboard techniques range.
- Added pictograms for metal rod (U+E6CF) and tuning key (U+E6D0) to harp techniques range.
- Added Smith Brindle’s pictograms for tuned percussion instruments (U+E6E5–U+E6E8).
- Added pictogram for Indian table (U+E720), plus stylistic alternate for tambourine (U+E718) as used by Stockhausen.
- Added pictogram for football rattle (U+E735), plus Smith Brindle’s pictogram for castanets (U+E738) as a stylistic alternate.
- Added pictogram for handbell (U+E765), plus stylistic alternates for cow bell (from Berio) and sleigh bell (from Smith Brindle).
- Added pictogram for Chinese cymbal (U+E776).
- Added pictogram for tam-tam with beater from Smith Brindle (U+E791).
- Added pictogram for maracas (U+E7A2), rainstick (U+E7A7), plus stylistic alternate for maraca from Smith Brindle (U+E7A1).
- Added pictogram for megaphone (U+E7B9).
- Added soft and hard glockenspiel beaters (U+E7F0–U+E7F7), superball beaters (U+E81C–U+E81F), wound beaters with hard and soft cores (U+E821–U+E828), plus soft, medium and hard gum beaters (U+E829–U+E834).
- Added pluck lift (U+E887) to handbells range.
- Added “Theme” indicators to analytics range (U+E8E4–U+E8E9).
- Added minor (minus sign) glyph (U+E904) to chord symbols range.
- Added mensural proportion glyphs (U+E9DB–U+E9DF).
- Added combining raise and lower glyphs (U+EA2C–U+EA2D) to figured bass range.
- Added repetition, angle brackets, and prefix + and ring glyphs to function symbols range (U+EA63–U+EA68).
- Added new range for multi-segment lines, including moving all of the various “wiggle” glyphs (for trill, glissando, arpeggiando, vibrato, etc.) plus the 11 ornament strokes from the Unicode Musical Symbols range into this range, and adding further glyphs for variable speed trills, alternate arpeggiato ending glyphs, wavy lines, squaretooth and sawtooth lines, group glissando, circular motion, and variable speed and intensity of vibrato (U+EA80–U+EAD0).
- Added new range of pictograms for electronic music, including microphone, loudspeaker, transport controls, volume level and MIDI controller level (U+EAE0–U+EAF5).
- Added new “do not copy” glyphs (U+EB02–U+EB03), eyeglasses (U+EB04) and choral divide arrows (U+EB05–U+EB07) glyphs to the miscellaneous symbols range.

29 July 2013 (Daniel Spreadbury) Bravura version 0.3
- Bravura 0.3 is designed to be compatible with SMuFL 0.6
- Bravura now incorporates glyphs from the Sagittal font by George Secor and Dave Keenan (U+E360–U+E47F). For more information about the Sagittal system of accidentals and to download the stand-alone Sagittal font, see http://sagittal.org.
- Changed registration of many glyphs in the font to match the interim guidelines for font metrics and glyph registration in SMuFL 0.6.
- Added complete set of dynamics to liga table, and duplicated these entries in the ccmp table.
- Added opening parenthesis and closing parenthesis for noteheads (U+E10A–U+E10B), circled slash notehead, heavy X and heavy X with hat noteheads, as used in Dante Agostini's drum method (U+E10C–U+E10E).
- Added muted slash noteheads (U+E125–U+E127).
- Added "si" note name noteheads for French solfège (U+E187, U+E18F, U+E197), and H sharp note name noteheads for German (U+E1AE, U+E1C5, U+E1DC).
- Fixed the vertical position of U+E227 and U+E228 (continuing beams for 8th notes with short and long stems), and made the stem thickness of beamed groups of notes consistent with those of individual notes.
- Added combining rim shot stem (U+E24E).
- Added "sharp sharp" accidental for compatibility with MusicXML (U+E2A9).
- Added extended Stein-Zimmermann accidentals with arrows (U+E2F8–U+E304).
- Adjusted size and registration of Sims microtonal accidentals (U+E308–U+E30D).
- Added one-third-tone sharp and two-third-tones sharp accidentals as used by Xenakis (U+E4B0–U+E4B1).
- Significant revision to the ornaments range, including splitting into separate ranges (common ornaments, other baroque ornaments, combining strokes for trills/mordents, precomposed trills/mordents). A small number of glyphs from previous versions of SMuFL have been removed to make way for symbols drawn from Frederick Neumann’s authoritative book on baroque ornamentation.
- The turn symbol and its derivates (U+E594 et al) have been redrawn to have a more open appearance, for better reproduction at small staff sizes or when read at a distance.
- Added thumb pizzicato (U+E654).
- Added recommended stylistic alternates for Bartok pizzicato above/below (U+E660–U+E661).
- Added recommended stylistic alternates for 'Ped.' (U+E6A0) and 'Sost.' (U+E6A5) that do not include terminal dots.
- Added choke cymbal glyph (U+E875) from Weinberg.
- Added open, half-open and closed wah/volume pedals, left- and right-hand tapping glyphs for guitar (U+E8AD–U+E8B1).
- Added new range for arrows and arrowheads (U+EB00–U+EB1F), including moving the up/down/right/left arrows from the vocal techniques range (previously U+E687–U+E68A) into this new range.
- Redesigned 'do not copy' glyph (U+E833) to be a bit more aggressive.

27 November 2013 (Daniel Spreadbury) Bravura version 0.7
- Bravura 0.7 is designed to be compliant with SMuFL 0.7; its version number has been bumped such that it matches the version number of SMuFL it implements
- Bravura now defines three stylistic sets: ss01 is for glyphs for use on small staves (i.e. different optical size); ss02 is for short up-stem flags to avoid augmentation dots; ss03 is for straight flags
- The Bravura distribution now includes a JSON metadata file describing various recommended metrics and engraving defaults for applications that wish to use Bravura; the specification for this metadata file is documented in the main SMuFL specification
- Significantly expanded the repertoire of glyphs for Medieval and Renaissance notation, with new ranges for clefs, accidentals and ligatures, plus considerable reworking of the notes and prolations ranges.
- Significantly expanded the repertoire of glyphs for plainchant notation, with new ranges for staves, divisions, clefs and articulations, and a wider range of neumes.
- Added range for Daseian notation, as found in the ninth century treatises Musica enchiriadis and Scolica enchiriadis.
- Added new range of control characters for adjusting the staff position of staff-relative glyphs; no ligatures using these control characters are yet defined in Bravura, however.
- Added control characters for time signature digits to allow digits to be stacked vertically, and ligatures for numerator and denominator digits.
- Added narrow and wide staff line glyphs, intended for fonts designed for text-based applications.
- Added C clef ottava bassa, and recommended stylistic alternate for G clef ottava bassa with parentheses around the 8.
- Added square double whole note (breve) notehead.
- Added new combining harp string noise for stem glyph, and corresponding precomposed stem glyph.
- Added four further quarter-tone accidental symbols to "other microtonal accidentals" group.
- Added some percussion playing technique symbols from Dante Agostini’s method books.
- Added a golpe (tap the pick guard) glyph from Claude Worm’s flamenco guitar method book.
- Added short and long fermata glyphs as used by Henze.
- Added combining glyphs for accordion couplers, allowing the creation of any coupler diagram not explicitly encoded.
- Added 'pf' dynamic.

3 February 2014 (Daniel Spreadbury) Bravura version 0.80
- Many minor changes to glyph outlines following corrections suggested by the Adobe FDK checkOutlines tool
- Corrected JSON metadata for stem connection points on flag glyphs (e.g. flag8thDown, flag16thUp, etc.)
- Changed glyph registration of left and right parentheses for noteheads (noteheadParenthesisLeft, noteheadParenthesisRight)
- Changed font name settings in accordance with FontLab's OpenType PS font name guidelines (http://forum.fontlab.com/index.php?topic=313.0).
- Added Ivan Wyschnegradsky’s system of 72-EDO accidentals.
- Added Bosanquet’s comma up/down.
- Added left/right parentheses for accidentals.
- Added new ranges for Renaissance lute tablature, covering French/English, Italian/Spanish and German conventions.
- Added Britten’s curlew sign for a pause of an indeterminate length.
- Added push/pull signs for accordion.
- Added slashed sharp/flat accidentals used by John Tavener in his Byzantine-inspired choral works.
- Added separate noteheads for white mensural notation.
- Added inverted signum congruentiae.
- Added combined tenuto-accent articulation.
- Added quasi-random wiggly lines (wiggleRandom1, wiggleRandom2, wiggleRandom3, wiggleRandom4) to multi-segment lines range.
- Added flipped and large versions of constant circular motion (wiggleCircularConstantFlipped, wiggleCircularConstantLarge, wiggleCircularConstantFlippedLarge) to multi-segment lines range.
- Added combining top/middle/bottom segments for black and white rectangular note clusters.
- Added 2, 3, 4 and 6-dot divisi indicators for measured tremolos (tremoloDivisiDots2, tremoloDivisiDots3, etc.) to tremolos range.
- Added clavichord bebung glyphs for 2, 3, and 4 finger movements (keyboardBebung2DotsAbove, keyboardBebung3DotsBelow, etc.) to the keyboard techniques range.
- Added double-height parentheses and brackets (csymParensLeftTall, csymParensRightTall, csymBracketLeftTall, csymBracketRightTall) to the chord symbols range.
- Added stylistic alternates for time signature digits 0–9 suitable for use as large time signatures shown above/between staves (timeSig0Large through timeSig9Large).
– Added 'sfzp' (sforzato-piano) dynamic and ligature.
– Added Penderecki's quarter-flat and Busotti's three-quarter sharp accidentals.
– Added six further accordion coupler diagrams for right-hand 3 rank accordions, and accordion ricochet glyphs.

9 March 2014 (Daniel Spreadbury) Bravura version 0.85
– Updated glyph registration for articulations, such that articulations above the note are positioned sitting on the baseline, and articulations below the note are positioned hanging from the baseline.
– Added whole and half rests with leger lines, i.e. as if displayed outside the staff.
– Added clef for diatonic accordion.
– Added recommended stylistic alternates for C and F clef forms used in 18th century French music, and for an F clef form used in 19th century music across Europe.
– Added half-brackets for keyboard notation to show notes that should be played by the other hand.
– Many code point changes, including moving the staff divide arrows, percussion swish arrow, and quite a few of the microtonal accidentals; refer to the SMuFL documentation for further details.
– Further revisions to the plainchant ranges, including adding reversed virga, smaller version of punctum inclinatum, moving the punctum mora to the plainchant articulations range, and eliminating the precomposed podatus and clivis glyphs in favour of individual components that provide the means to construct these easily for any interval.
– Added new range for Kievian square notation, as used for liturgical chant in the Russian Orthodox Church.
– Added new glyphs for tabling one handbell and tabling a pair of handbells.
– Added alternative pedal heel glyph and pedal heel or toe glyph.
– Added recommended stylistic alternates for braces designed for use across different sizes of gaps, designed to be scaled uniformly rather than simply stretched vertically.
– Added many new electronic music pictograms, including speaker configurations, more transport controls, additional hardware devices, and so on.
– Added guitar fade in, fade out and swell glyphs.
– Added the glyphs used by the Corpus Monodicum project for modern transcription of plainchant.

17 April 2014 (Daniel Spreadbury) Bravura version 0.9
– Distribution now includes Bravura Text font, intended for use in text-based applications.
– Added new range for Kodály solfège hand signs.
– Added new range for Peter Hayes George’s Simplified Music Notation.
– Added narrow and wide versions of the sine wave, square wave and sawtooth wavy lines.
– Added wide versions of the black and white diamond noteheads, as used in some handbells music.
– Added turned (i.e. inverted) versions of up bow and down bow marks.
– Added oriscus liquescens and strophicus liquescens (for intervals of a second up to a fifth).
– Added oblique ligature forms for mensural notes describing intervals of a second up to a fifth for black, void, black and void, and white noteheads.
– Added single glyph for right and left repeat barlines, and a stylistic alternate using thick-thick rather than thin-thick-thin barlines.
– Added reversed versions of brackets to denote play with right/left hand, to allow the demarcation of the end of a passage to be played with the other hand.
– Extended stylistic set 01 (ss01) with new glyphs redesigned for display on smaller staff sizes: time signature digits; G, C and F clef; black, half, whole and double whole noteheads; standard articulations; dynamics letter forms; flags.
– Added recommended ligatures for standard noteheads and accidentals in parentheses.
– Improved registration of ornamentMiddleVerticalStroke.
– Added open arrowheads and arrows.
– Added Kievan half note on space, and Kievan beam.
– Added new percussion pictograms from the books by Sevsay and Peinkofer/Tannigel, plus new combining glyphs for stems showing the "crush" rudiment, "dead" notes, and to instruct the performer to turn the instrument.
– Added five further mensural proportion signs, from Apel's book.
– Added 12 new precomposed trills and mordents, based on Bach's ornamentation chart and ornaments found in Emmentaler.
– Added restHBarMiddle glyph, for text-based applications to construct H-bar multirests of variable width.
– Added noteheadWholeFilled and noteheadHalfFilled, for modern transcriptions of coloration in Medieval and Renaissance music.
– Consolidated breath marks into a single range, and added a new upbow-like breath mark (as used in music from Russia).
– Added range of glyphs for lyrics, including three lengths of elision undertie, and baseline hyphen (as used in music from Russia).
– Added a wider slash notehead, for whole note (semibreve) duration.
– Added more shape note noteheads to support the 7-shape conventions of Joseph Funk and William Walker.
– Added maxima rest, and double whole (breve) rest with leger lines above and below.
– Added curved caesura.
– Added separate glyphs for the 'e', 'd' and dot in keyboard Ped. marks, plus a curved hyphen to be used along with the 'P' to show start/end pedal in some editions.
– Added new mensural C clef, plus variations of the Petrucci C clef for different staff positions.
– Added different custos for different staff positions.
– Added stylistic alternates for the Medieval and Renaissance "soft b" flat accidental.
– Added dedicated glyphs for C, G, and F clef changes, plus new combining clef change character to produce other clef change glyphs by way of glyph substitution (other clef change glyphs not currently implemented in Bravura).
– Added one- and two-third tones sharp and flat accidentals as used by Brian Ferneyhough.
– Added "just air" open diamond notehead as used by Brian Ferneyhough.
– Added white and wide white diamond noteheads.
– Added a range of glyphs for denoting accel./rit. beam lines above the staff.
– Added normal, wide and narrow leger line glyphs.

12 June 2014 (Abraham Lee) Profondo 1.0
– Re-mapped the classical Bravura glyphs to be compatible with LilyPond 2.18.2.

25 October 2014 (Abraham Lee) Profondo version 1.0
- Added WOFF font file support and added piano brace font in OTF, SVG, and WOFF formats
