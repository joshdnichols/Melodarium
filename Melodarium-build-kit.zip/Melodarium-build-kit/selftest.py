# Melodarium - selftest.py (build check)
# Copyright (C) 2026 Joshua Nichols
# https://github.com/joshdnichols/Melodarium
#
# This program is free software: you can redistribute it and/or modify it under the
# terms of the GNU General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your option) any later version.
# This program is distributed WITHOUT ANY WARRANTY; see the file LICENSE for details.
"""Build check for Melodarium: engraves short test scores with the LilyPond that
was just bundled and checks the results. Used by build_windows.ps1 and build_mac.sh.

    python selftest.py <path to bundled lilypond executable>

Prints PASS/FAIL lines and exits with 0 only if everything passed."""
import importlib.util
import os
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
EXPECTED_FONTS = ["beethoven", "cadence", "gonville", "gutenberg1939", "haydn", "improviso",
                  "lilyboulez", "lv-goldenage", "paganini", "profondo", "ross", "scorlatti",
                  "sebastiano"]


def load_app():
    spec = importlib.util.spec_from_file_location("melodarium",
                                                  os.path.join(HERE, "melodarium.py"))
    app = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(app)
    return app


def main():
    if len(sys.argv) != 2 or not os.path.isfile(sys.argv[1]):
        print("usage: python selftest.py <path to lilypond executable>")
        return 2
    lilypond = os.path.abspath(sys.argv[1])
    app = load_app()
    failures = 0

    def check(ok, what):
        nonlocal failures
        print(("PASS  " if ok else "FAIL  ") + what, flush=True)
        failures += 0 if ok else 1

    r = subprocess.run([lilypond, "--version"], capture_output=True, text=True,
                       creationflags=app.NO_WINDOW)
    check(r.returncode == 0 and "2.26" in r.stdout, "LilyPond runs: " + (r.stdout.splitlines() or ["?"])[0])

    fonts = app.lilypond_music_fonts(lilypond)
    missing = [f for f in EXPECTED_FONTS if f not in fonts]
    check(not missing, "music fonts installed in LilyPond" + (f" (missing: {', '.join(missing)})" if missing else ""))

    tmp = tempfile.mkdtemp(prefix="np-selftest-")
    try:
        cases = [("", False, "Emmentaler, fonts embedded"),
                 ("gonville", True, "Gonville, music to outline"),
                 ("cadence", False, "Cadence (outline is forced on)")]
        for k, (font, outline, label) in enumerate(cases):
            settings, err = app.validate({"length": 4, "notes": ["c", "cis", "d", "e"], "max_kb": 1000,
                                          "music_font": font, "outline_fonts": outline,
                                          "save_to": tmp})
            if err:
                check(False, f"{label}: settings rejected: {err}")
                continue
            plan = app.Plan(settings)
            name = f"test{k}"
            with open(os.path.join(tmp, name + ".ly"), "w") as f:
                f.write(plan.whole_file(plan.first, min(plan.last, plan.first + 23), 1, name))
            with open(os.path.join(tmp, app.CC0_EPS_NAME), "w") as f:
                f.write(app.CC0_EPS)
            r = subprocess.run([lilypond, name + ".ly"], cwd=tmp, capture_output=True, text=True,
                               errors="replace", creationflags=app.NO_WINDOW)
            pdf = os.path.join(tmp, name + ".pdf")
            ok = r.returncode == 0 and os.path.isfile(pdf)
            check(ok, f"{label}: PDF engraved")
            if not ok:
                print("\n".join((r.stdout + r.stderr).splitlines()[-15:]))
                continue
            embedded = app.music_font_embedded(pdf, font)
            if plan.outline_fonts:
                check(not embedded, f"{label}: music font NOT embedded (drawn as shapes)")
                check(len(app.pdf_font_names(pdf)) > 0, f"{label}: text font still embedded")
            else:
                check(embedded, f"{label}: music font embedded")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    print("\nALL CHECKS PASSED" if not failures else f"\n{failures} CHECK(S) FAILED")
    return 0 if not failures else 1


if __name__ == "__main__":
    sys.exit(main())
