@echo off
rem Melodarium - BUILD-WINDOWS.bat
rem Copyright (C) 2026 Joshua Nichols
rem https://github.com/joshdnichols/Melodarium
rem
rem This program is free software: you can redistribute it and/or modify it under the
rem terms of the GNU General Public License as published by the Free Software
rem Foundation, either version 3 of the License, or (at your option) any later version.
rem This program is distributed WITHOUT ANY WARRANTY; see the file LICENSE for details.
rem Double-click this to build the Windows app. It runs build_windows.ps1 and keeps
rem the window open at the end so you can read the result.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_windows.ps1"
echo.
pause
