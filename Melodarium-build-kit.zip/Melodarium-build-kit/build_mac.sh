#!/bin/bash
# Melodarium - build_mac.sh (builds the Mac app)
# Copyright (C) 2026 Joshua Nichols
# https://github.com/joshdnichols/Melodarium
#
# This program is free software: you can redistribute it and/or modify it under the
# terms of the GNU General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your option) any later version.
# This program is distributed WITHOUT ANY WARRANTY; see the file LICENSE for details.
# ---------------------------------------------------------------------------
#  Builds the Mac app "Melodarium.app" (LilyPond and the music fonts inside)
#  and a .dmg disk image for sharing.
#
#  Run it in Terminal from this folder:      bash build_mac.sh
#
#  Needs: Python 3.11-3.14 from python.org, the Xcode Command Line Tools
#  (xcode-select --install), internet access for the Python packages and (unless
#  already in this folder) the LilyPond download.
#
#  Optional, only for sharing with other Macs without security warnings (needs a paid
#  Apple Developer account; see the instructions):
#     SIGN_ID="Developer ID Application: Your Name (TEAMID)" NOTARY_PROFILE=np bash build_mac.sh
# ---------------------------------------------------------------------------
set -euo pipefail
cd "$(dirname "$0")"
KIT="$(pwd)"

APP_NAME="Melodarium"
BUNDLE_ID="${BUNDLE_ID:-org.melodarium.app}"
APP_VERSION="${APP_VERSION:-1.0}"
LY_VERSION="2.26.0"
LY_SHORT="2.26"
SIGN_ID="${SIGN_ID:--}"            # "-" = ad-hoc signature (fine on your own Mac)
NOTARY_PROFILE="${NOTARY_PROFILE:-}"

BUILD="$KIT/build"
DIST="$KIT/dist"
DOWNLOADS="$KIT/downloads"
VENV="$BUILD/venv"
APP="$DIST/$APP_NAME.app"

step() { printf '\n\033[1;36m==> %s\033[0m\n' "$1"; }
fail() { printf '\n\033[1;31mBUILD STOPPED: %s\033[0m\n' "$1"; exit 1; }

# --- 0. kit complete? -------------------------------------------------------
for need in melodarium.py selftest.py collect_licenses.py LICENSE NOTICE.txt icon.icns entitlements.plist licenses fonts/otf fonts/svg; do
  [ -e "$KIT/$need" ] || fail "'$need' is missing from this folder. Unzip the whole build kit first."
done

# --- 1. this Mac ---------------------------------------------------------------
step "Checking this Mac"
ARCH="$(uname -m)"
case "$ARCH" in
  arm64)  LY_ARCH="arm64" ;;
  x86_64) LY_ARCH="x86_64" ;;
  *) fail "Unknown processor type: $ARCH" ;;
esac
echo "Processor: $ARCH (building for this kind of Mac)"
command -v codesign >/dev/null || fail "Xcode Command Line Tools are missing. Run: xcode-select --install"

PY=""
for cand in python3.13 python3.12 python3.14 python3.11 python3; do
  if command -v "$cand" >/dev/null && "$cand" -c 'import sys; sys.exit(0 if (3,11) <= sys.version_info[:2] <= (3,14) else 1)' 2>/dev/null; then
    PY="$(command -v "$cand")"; break
  fi
done
[ -n "$PY" ] || fail "Python 3.11-3.14 wasn't found. Install it from python.org (step 1 of the instructions)."
"$PY" --version

LY_TGZ="lilypond-$LY_VERSION-darwin-$LY_ARCH.tar.gz"
LY_URL="https://gitlab.com/lilypond/lilypond/-/releases/v$LY_VERSION/downloads/$LY_TGZ"
LY_SRC="lilypond-$LY_VERSION.tar.gz"
LY_SRC_URL="https://lilypond.org/download/source/v$LY_SHORT/$LY_SRC"

# --- 2. build tools in a private virtual environment -------------------------
step "Installing PyInstaller and Pillow (for building) and pywebview (the app window)"
mkdir -p "$BUILD" "$DOWNLOADS" "$DIST"
[ -x "$VENV/bin/python" ] || "$PY" -m venv "$VENV"
VPY="$VENV/bin/python"
"$VPY" -m pip install --upgrade pip >/dev/null
"$VPY" -m pip install --upgrade "pyinstaller>=6.10,<7" "pillow>=10" "pywebview>=5,<7" || fail "Couldn't install PyInstaller/Pillow/pywebview (check the internet connection)."
"$VPY" -c "import webview" || fail "pywebview was installed but doesn't load (see the error above)."
echo "Collecting the licenses of the Python packages that go inside the app:"
"$VPY" "$KIT/collect_licenses.py" "$BUILD/licenses-python" pywebview || fail "Couldn't collect the package licenses (see above)."

# --- 3. LilyPond -------------------------------------------------------------
step "Getting LilyPond $LY_VERSION for Mac ($LY_ARCH)"
TGZ="$KIT/$LY_TGZ"
[ -f "$TGZ" ] || TGZ="$DOWNLOADS/$LY_TGZ"
if [ ! -f "$TGZ" ]; then
  echo "Downloading $LY_URL"
  curl -fL --retry 3 -o "$TGZ" "$LY_URL" || fail "Couldn't download LilyPond. Download $LY_TGZ yourself into this folder and run again."
fi
LY_STAGE="$BUILD/lilypond"
rm -rf "$LY_STAGE"; mkdir -p "$LY_STAGE"
tar -xzf "$TGZ" -C "$LY_STAGE"
LY_ROOT="$LY_STAGE/lilypond-$LY_VERSION"
[ -x "$LY_ROOT/bin/lilypond" ] || fail "The LilyPond download doesn't contain lilypond-$LY_VERSION/bin/lilypond."
xattr -dr com.apple.quarantine "$LY_ROOT" 2>/dev/null || true   # downloaded files: allow them to run

# --- 4. music fonts into LilyPond's own font folders -------------------------
step "Installing the music fonts into LilyPond"
FONT_DIR="$LY_ROOT/share/lilypond/$LY_VERSION/fonts"
cp -f "$KIT"/fonts/otf/* "$FONT_DIR/otf/"
cp -f "$KIT"/fonts/svg/* "$FONT_DIR/svg/"
echo "$(find "$KIT/fonts/otf" "$KIT/fonts/svg" -type f | wc -l | tr -d ' ') font files installed."

# --- 5. check LilyPond + fonts + outline before packaging --------------------
step "Self-test: engraving test scores with the bundled LilyPond"
"$VPY" "$KIT/selftest.py" "$LY_ROOT/bin/lilypond" || fail "The self-test failed (see the FAIL lines above)."

# --- 6. the app itself -------------------------------------------------------
step "Building $APP_NAME.app with PyInstaller"
rm -rf "$APP" "$DIST/$APP_NAME"
"$VPY" -m PyInstaller --noconfirm --clean \
  --onedir --windowed \
  --name "$APP_NAME" \
  --icon "$KIT/icon.icns" \
  --osx-bundle-identifier "$BUNDLE_ID" \
  --add-data "$KIT/licenses:licenses" \
  --add-data "$BUILD/licenses-python:licenses/python" \
  --collect-all webview \
  --distpath "$DIST" --workpath "$BUILD/pyinstaller" --specpath "$BUILD" \
  "$KIT/melodarium.py" || fail "PyInstaller reported an error (see above)."
rm -rf "$DIST/$APP_NAME"        # the loose folder version; the .app is what we keep

# --- 7. LilyPond goes inside the app, in Contents/Resources ------------------
step "Adding LilyPond to the app"
mkdir -p "$APP/Contents/Resources/lilypond"
ditto "$LY_ROOT" "$APP/Contents/Resources/lilypond/lilypond-$LY_VERSION"

# --- 8. app settings (Info.plist) --------------------------------------------
PLIST="$APP/Contents/Info.plist"
# the app has its own window, so it keeps its Dock icon and menu bar
/usr/libexec/PlistBuddy -c "Delete :LSUIElement" "$PLIST" 2>/dev/null || true
/usr/libexec/PlistBuddy -c "Delete :NSHighResolutionCapable" "$PLIST" 2>/dev/null || true
/usr/libexec/PlistBuddy -c "Add :NSHighResolutionCapable bool true" "$PLIST"
/usr/libexec/PlistBuddy -c "Delete :NSDocumentsFolderUsageDescription" "$PLIST" 2>/dev/null || true
/usr/libexec/PlistBuddy -c "Add :NSDocumentsFolderUsageDescription string 'Melodarium keeps its settings and saves your scores in Documents/Melodarium.'" "$PLIST"
/usr/libexec/PlistBuddy -c "Delete :LSMinimumSystemVersion" "$PLIST" 2>/dev/null || true
/usr/libexec/PlistBuddy -c "Add :LSMinimumSystemVersion string 10.15" "$PLIST"
/usr/libexec/PlistBuddy -c "Set :CFBundleShortVersionString $APP_VERSION" "$PLIST" 2>/dev/null || true
/usr/libexec/PlistBuddy -c "Delete :NSHumanReadableCopyright" "$PLIST" 2>/dev/null || true
/usr/libexec/PlistBuddy -c "Add :NSHumanReadableCopyright string 'Copyright © 2026 Joshua Nichols. Free software under the GNU GPL v3 or later.'" "$PLIST"

# --- 9. sign everything, innermost first ---------------------------------------
if [ "$SIGN_ID" = "-" ]; then
  step "Signing (ad-hoc: fine for this Mac)"
  SIGN_OPTS=(--force --sign -)
else
  step "Signing with: $SIGN_ID"
  SIGN_OPTS=(--force --sign "$SIGN_ID" --options runtime --timestamp --entitlements "$KIT/entitlements.plist")
fi
# every program and library inside the app, deepest paths first
find "$APP/Contents" -type f -print0 | while IFS= read -r -d '' f; do
  if file -b "$f" | grep -q "Mach-O"; then
    printf '%s\t%s\n' "$(echo "$f" | tr -cd '/' | wc -c)" "$f"
  fi
done | sort -rn | cut -f2- | while IFS= read -r f; do
  codesign "${SIGN_OPTS[@]}" "$f" >/dev/null 2>&1 || { echo "could not sign: $f"; exit 1; }
done
codesign "${SIGN_OPTS[@]}" "$APP"
codesign --verify --deep --strict "$APP" && echo "Signature OK."

# --- 10. self-test again, from inside the finished app ---------------------------
step "Self-test again, from inside the finished app"
"$VPY" "$KIT/selftest.py" "$APP/Contents/Resources/lilypond/lilypond-$LY_VERSION/bin/lilypond" \
  || fail "The self-test failed inside the app."

# --- 11. disk image for sharing (+ LilyPond source for the GPL) ----------------
step "Fetching LilyPond's source code (shipped alongside the app for the GPL)"
SRC="$DOWNLOADS/$LY_SRC"
[ -f "$SRC" ] || curl -fL --retry 3 -o "$SRC" "$LY_SRC_URL" \
  || echo "Couldn't download $LY_SRC_URL - put it in the 'downloads' folder yourself before sharing."

step "Making the disk image"
DMG_STAGE="$BUILD/dmg"
rm -rf "$DMG_STAGE"; mkdir -p "$DMG_STAGE/Source code"
ditto "$APP" "$DMG_STAGE/$APP_NAME.app"
ln -s /Applications "$DMG_STAGE/Applications"
[ -f "$SRC" ] && cp "$SRC" "$DMG_STAGE/Source code/"
# Melodarium's own source: this kit, without the build output and downloads (for the GPL)
SRC_STAGE="$BUILD/source/Melodarium-source"
rm -rf "$BUILD/source"; mkdir -p "$SRC_STAGE"
rsync -a --exclude '/build' --exclude '/dist' --exclude '/downloads' --exclude '*.tar.gz' \
  --exclude '/lilypond-*.zip' --exclude '__pycache__' --exclude '.DS_Store' "$KIT/" "$SRC_STAGE/"
ditto -c -k --keepParent "$SRC_STAGE" "$DMG_STAGE/Source code/Melodarium-source.zip"
cp "$KIT/LICENSE" "$DMG_STAGE/LICENSE.txt"
cp "$KIT/NOTICE.txt" "$DMG_STAGE/NOTICE.txt"
cat > "$DMG_STAGE/READ ME.txt" <<EOF
Melodarium
==========
Drag "Melodarium" onto the Applications folder, then open it from Applications.
It opens in its own window. Closing the window (or Quit in it) quits the app; progress is
saved, and pressing Start again resumes.

Your settings, progress and (by default) your scores are kept in Documents/Melodarium.

Copyright (C) 2026 Joshua Nichols. Melodarium is free software: you can share and change
it under the GNU General Public License, version 3 or (at your option) any later version
(LICENSE.txt). It comes with NO WARRANTY, to the extent permitted by law. The code it
writes into your scores may be used under CC0 1.0 (public domain); see NOTICE.txt.
Source code: in the "Source code" folder, and at
https://github.com/joshdnichols/Melodarium

Included software and fonts, with their licenses, are listed on the Acknowledgements page
(link at the top of the control panel). LilyPond is free software under the GNU General
Public License v3; its source code is in the "Source code" folder and at
$LY_SRC_URL
EOF
DMG="$DIST/Melodarium-Mac-$LY_ARCH.dmg"
rm -f "$DMG"
hdiutil create -volname "$APP_NAME" -srcfolder "$DMG_STAGE" -ov -format UDZO "$DMG" >/dev/null
if [ "$SIGN_ID" != "-" ]; then
  codesign --force --sign "$SIGN_ID" --timestamp "$DMG"
fi

# --- 12. optional: notarize -------------------------------------------------------
if [ -n "$NOTARY_PROFILE" ]; then
  [ "$SIGN_ID" != "-" ] || fail "Notarizing needs SIGN_ID (a Developer ID Application certificate)."
  step "Notarizing with Apple (takes a few minutes)"
  xcrun notarytool submit "$DMG" --keychain-profile "$NOTARY_PROFILE" --wait
  xcrun stapler staple "$DMG"
fi

printf '\n\033[1;32mDONE.\033[0m\n'
echo "  App:        $APP"
echo "  To share:   $DMG"
[ "$SIGN_ID" = "-" ] && echo "  (Ad-hoc signed: other Macs will warn about it; see the instructions.)"
exit 0
