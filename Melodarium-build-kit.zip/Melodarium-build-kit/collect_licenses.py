# Melodarium - collect_licenses.py
# Copyright (C) 2026 Joshua Nichols
# https://github.com/joshdnichols/Melodarium
#
# This program is free software: you can redistribute it and/or modify it under the
# terms of the GNU General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your option) any later version.
# This program is distributed WITHOUT ANY WARRANTY; see the file LICENSE for details.
"""Build step: copies the license files of the Python packages that go inside the app
(pywebview and everything it needs on this computer, such as pythonnet on Windows or
PyObjC on a Mac) into one folder, with a small info.json for each package. The build
bundles that folder as licenses/python, and the app's Acknowledgements page lists it.

Usage:  python collect_licenses.py OUTPUT_FOLDER [package ...]   (default: pywebview)
Run it with the Python the app is built with, so the installed versions are listed."""
import json
import os
import re
import shutil
import sys
from importlib import metadata

try:
    from packaging.requirements import Requirement
except ImportError:                                  # pip always carries a copy
    from pip._vendor.packaging.requirements import Requirement

LICENSE_FILE = re.compile(r"(^|/)(LICEN[CS]E|COPYING|NOTICE|AUTHORS)[^/]*$", re.I)


def norm(name):
    return re.sub(r"[-_.]+", "-", name).lower()


def runtime_closure(roots):
    """Every installed package the roots need on this computer (extras left out)."""
    seen, todo = {}, list(roots)
    while todo:
        name = todo.pop()
        key = norm(name)
        if key in seen:
            continue
        try:
            dist = metadata.distribution(name)
        except metadata.PackageNotFoundError:
            continue
        seen[key] = dist
        for spec in dist.requires or []:
            req = Requirement(spec)
            if req.marker is None or req.marker.evaluate({"extra": ""}):
                todo.append(req.name)
    return seen


def license_name(dist):
    md = dist.metadata
    expr = md.get("License-Expression")
    if expr:
        return expr.strip()
    lic = (md.get("License") or "").strip()
    if lic and len(lic) < 80 and "\n" not in lic:
        return lic
    for c in md.get_all("Classifier") or []:
        if c.startswith("License ::"):
            return c.split("::")[-1].strip()
    return lic.splitlines()[0][:80] if lic else "see the license file"


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    out = os.path.abspath(sys.argv[1])
    roots = sys.argv[2:] or ["pywebview"]
    if os.path.isdir(out):
        shutil.rmtree(out)
    os.makedirs(out)
    missing = []
    for key, dist in sorted(runtime_closure(roots).items()):
        name, version = dist.metadata["Name"], dist.version
        folder = os.path.join(out, key)
        os.makedirs(folder)
        files = []
        for f in dist.files or []:
            if LICENSE_FILE.search(str(f)):
                src = dist.locate_file(f)
                if os.path.isfile(src):
                    dest = os.path.basename(str(f))
                    if dest in files:                       # two files of one name: keep both
                        dest = f"{len(files)}-{dest}"
                    shutil.copyfile(src, os.path.join(folder, dest))
                    files.append(dest)
        if not files:                                      # some packages ship no license file:
            text = dist.metadata.get("License") or ""     # keep what their metadata says
            if len(text) > 200:
                with open(os.path.join(folder, "LICENSE.txt"), "w", encoding="utf-8") as fh:
                    fh.write(text)
                files.append("LICENSE.txt")
            else:
                missing.append(name)
        urls = [u.split(",", 1)[-1].strip() for u in dist.metadata.get_all("Project-URL") or []]
        home = dist.metadata.get("Home-page") or (urls[0] if urls else "")
        with open(os.path.join(folder, "info.json"), "w", encoding="utf-8") as fh:
            json.dump({"name": name, "version": version, "license": license_name(dist),
                       "home": home, "files": files}, fh, indent=1)
        print(f"  {name} {version}: {license_name(dist)} ({', '.join(files) or 'no license file'})")
    if missing:
        print("  Note: no license file inside " + ", ".join(missing)
              + "; the Acknowledgements page names their license and links to the project instead.")


if __name__ == "__main__":
    main()
